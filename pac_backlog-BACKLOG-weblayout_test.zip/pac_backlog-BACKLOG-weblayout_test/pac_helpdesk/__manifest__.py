# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.


{
    'name': "Pac helpdesk",

    'summary': """
            Add Fields To Helpdesk
        """,
    'description': """
            Add scheduled time and actual time.
            Add Project Key And Ticket Key To Helpdesk.
            Add a category item.
            Add WiKi notes.
    """,
    'author': "pactera DL",
    'website': "https://japan-odoo.com/",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'helpdesk'],# any module necessary for this one to work correctly
    'data': [
        'security/ir.model.access.csv',
        'views/helpdesk_category_view.xml',
        'views/helpdesk_category_item_view.xml',
        'views/helpdesk_ticket.xml',
        'views/helpdesk_team.xml',
        'views/wiki.xml',
        'views/helpdesk_wiki.xml',
        'views/menu.xml',
    ],
    'application': False,
    'installable': True,
}