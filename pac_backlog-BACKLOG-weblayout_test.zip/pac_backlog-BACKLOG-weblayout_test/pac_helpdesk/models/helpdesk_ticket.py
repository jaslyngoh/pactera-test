# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api


class HelpdeskTicket(models.Model):
    _inherit = 'helpdesk.ticket'

    scheduled_time = fields.Char(string='Scheduled Time')  # Defining field types
    actual_time = fields.Char(string='Actual Time')
    ticket_key = fields.Char(string="Ticket Key")
    # Add category filtering.
    category_id = fields.Many2one('helpdesk.category.item', string="Category", ondelete='restrict')
    category_id_display = fields.Many2one('helpdesk.category.type', string="Category id",
                                          related='team_id.category_group', store=True)

    @api.onchange('team_id')
    def _onchange_team(self):
        self.category_id = False

    @api.model
    def create(self, vals):
        if vals.get('team_id'):
            teams = self.env['helpdesk.team'].browse(vals['team_id'])
            key_name = teams.key_name
            get_key_name = self.env['ir.sequence'].next_by_code(key_name)
            if get_key_name:
                vals['ticket_key'] = get_key_name
            # add ticket_key when creating
            tickets = super(HelpdeskTicket, self).create(vals)
            return tickets

    def write(self, vals):
        if 'active' in vals:
            self.with_context(active_test=False).mapped('ticket_ids').write({'active': vals['active']})
        teams = self.env['helpdesk.team'].browse(vals.get('team_id'))
        if teams:
            name = str(teams)
            key_name = teams.key_name
            sq = self.env['ir.sequence'].sudo().search([('name', '=', name)])
            if sq:
                sq.write({'prefix': key_name + "_"})
            else:
                sq.create({'name': name, 'code': key_name, 'prefix': key_name + "_"})
            # Update the ticket_key when writing
            get_key_name = self.env['ir.sequence'].next_by_code(key_name)
            vals['ticket_key'] = get_key_name
        result = super(HelpdeskTicket, self).write(vals)
        return result

    def name_get(self):
        # Hide # in title
        result = []
        for ticket in self:
            result.append((ticket.id, "%s" % ticket.name))
        return result
