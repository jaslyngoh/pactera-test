# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.
import re

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

# PROJECT KEY REGEX
PROJECT_KEY_REGEX = r'[a-zA-Z0-9_]+$'


class HelpdeskTeamPac(models.Model):
    _inherit = 'helpdesk.team'

    key_name = fields.Char(string="Project Key", required=True)
    category_group = fields.Many2one('helpdesk.category.type', string="Category", ondelete='restrict', required=True)

    # Data Verification: Project Key Unique
    _sql_constraints = [
        ('key_name_uniq', 'unique(key_name)', 'The project key name already exists.'),
    ]

    # PROJECT KEY REGEX
    @api.constrains('key_name')
    def _check_key_name(self):
        # Pop up warnings when not meet the conditions
        if not re.match(PROJECT_KEY_REGEX, self.key_name):
            raise ValidationError(_('Please enter half-width alphanumeric characters and _.'))

    @api.model
    def create(self, vals):
        team = super(HelpdeskTeamPac, self.with_context(mail_create_nosubscribe=True)).create(vals)
        name = str(team)
        key_name = team.key_name
        # create sequence
        self.env['ir.sequence'].sudo().create({'name': name, 'code': key_name, 'prefix': key_name + "_"})
        return team

    def write(self, vals):
        result = super(HelpdeskTeamPac, self).write(vals)
        if 'active' in vals:
            self.with_context(active_test=False).mapped('ticket_ids').write({'active': vals['active']})
        if 'key_name' in vals:
            name = str(self)
            key_name = self.key_name
            sq = self.env['ir.sequence'].sudo().search([('name', '=', name)])
            if sq:
                sq.write({'name': name,
                          'code': key_name,
                          'prefix': key_name + "_"})
            else:
                self.env['ir.sequence'].sudo().create({'name': name, 'code': key_name, 'prefix': key_name + "_"})
            # Update the ticket_key of the ticket when modifying the team name
            tickets = self.env['helpdesk.ticket'].sudo().search([('team_id', '=', self.id)])
            for ticket in tickets:
                if ticket.ticket_key:
                    ticket_key = key_name + "_" + ticket.ticket_key.split('_')[-1]
                    ticket.write({'ticket_key': ticket_key})
        return result

    def unlink(self):
        stages = self.mapped('stage_ids').filtered(
            lambda stage: stage.team_ids <= self)  # remove stages that only belong to team in self
        stages.unlink()
        name = str(self)
        sq = self.env['ir.sequence'].sudo().search([('name', '=', name)])
        if sq:
            sq.unlink()
        return super(HelpdeskTeamPac, self).unlink()
