# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ProjectDeleteTicketType(models.Model):
    _inherit = 'helpdesk.ticket.type'
        #Modify the original method of deleting data

    def unlink(self):
        """
        Query before deleting if task has enabled tasktype
        :return:
        """
        for record in self:
            sq = self.env['helpdesk.ticket'].sudo().search([('ticket_type_id', '=', record.id)])
            if not sq:
                sq.unlink()
            else:
                raise ValidationError(
                    _("The operation cannot be completed: another model requires the record being deleted."
                      "If possible, archive it instead.\n\n" 
                      "Model: Task (helpdesk.ticket), Constraint: helpdesk_ticket_type_fkey"))
            return super(ProjectDeleteTicketType, self).unlink()
