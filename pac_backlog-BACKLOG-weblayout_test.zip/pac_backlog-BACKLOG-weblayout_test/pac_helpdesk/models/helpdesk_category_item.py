# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api


class HelpdeskCategoryItem(models.Model):
    _name = 'helpdesk.category.item'
    _description = 'Helpdesk Category Item'
    _order = 'sequence'

    name = fields.Char(string='Category Item', required=True, translate=True)
    category_id = fields.Many2one('helpdesk.category.type', string="Category")
    sequence = fields.Integer(default=10)
