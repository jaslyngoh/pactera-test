# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api


class HelpdeskCategory(models.Model):
    _name = 'helpdesk.category.type'
    _description = 'Helpdesk Category Type'
    _order = 'sequence'
    _rec_name = 'category_group'

    category_group = fields.Char(string='Category Name', required=True)
    sequence = fields.Integer(default=10)

    category_id = fields.One2many('helpdesk.category.item', 'category_id', string="Category item", ondelete='restrict')

    _sql_constraints = [
        ('name_uniq', 'unique (name)', "Type name already exists !"),
    ]
