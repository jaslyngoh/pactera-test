# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.


{
    'name': "Pac Website",
    'summary': """Use project Key in Website Helpdesk""",
    'description': """Use project Key in Website Helpdesk""",
    'author': "pactera DL",
    'website': "https://japan-odoo.com/",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'pac_project', 'pac_helpdesk', 'website_helpdesk'],
    'data': [
        'views/website_helpdesk_project.xml',
    ],
    'application': False,
    'installable': True,
}
