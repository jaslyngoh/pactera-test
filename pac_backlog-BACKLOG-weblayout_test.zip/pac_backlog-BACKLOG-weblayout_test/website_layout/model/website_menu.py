# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class Menu(models.Model):
    _inherit = "website.menu"
    _description = "Website Menu"

    @api.model
    def create(self, vals):
        # Only used when creating website_data.xml default menu
        if vals.get('url') == '/default-main-menu':
            return super(Menu, self).create(vals)

        if 'website_id' in vals:
            return super(Menu, self).create(vals)
        elif self._context.get('website_id'):
            vals['website_id'] = self._context.get('website_id')
            return super(Menu, self).create(vals)
        else:
            # create for every site
            website_total = self.env['website'].search_count([])
            for website in self.env['website'].search([]):
                # modify submenu in website
                if int(vals.get('parent_id')) != self.env.ref('website.main_menu').id:
                    w_vals = dict(vals, **{
                        'website_id': website.id,
                        'parent_id': int(vals.get('parent_id')) - website_total,
                    })
                    website_total -= 1
                    res = super(Menu, self).create(w_vals)
            # if creating a default menu, we should also save it as such
            default_menu = self.env.ref('website.main_menu', raise_if_not_found=False)
            if default_menu and vals.get('parent_id') == default_menu.id:
                res = super(Menu, self).create(vals)
        return res
