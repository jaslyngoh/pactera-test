# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.


{
    'name': "Website Layout",
    'summary': """Website Layout""",
    'description': """
    * Home Page
        * Homepage Introduction
        * System Function Description
    * My Account
        * Project and Helpdesk
    * Odoo
        * Common Problem
        * Club Summary
    * Website Helpdesk
        * Submit a Ticket
    Website Home Page,My Account And Website Helpdesk""",
    'author': "Pactera DL",
    'website': "https://japan-odoo.com/",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'pac_website', 'website', 'website_helpdesk_form'],
    'data': [
        'views/task.xml',
        'views/ticket.xml',
        'views/home.xml',
        'views/club_summary.xml',
        'views/trouble.xml',
        'views/helpdesk.xml',
        'views/problem.xml',
        'data/menu_data.xml',
        'views/footer.xml',
        'views/css.xml',
        'views/contactus.xml',
        'views/login.xml',
    ],
    'application': False,
    'installable': True,
}
