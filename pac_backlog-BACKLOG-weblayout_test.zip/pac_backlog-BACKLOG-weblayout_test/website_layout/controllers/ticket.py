# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import http
from odoo.http import request
from odoo.tools.translate import _
from odoo.osv.expression import OR
from collections import OrderedDict

from odoo.addons.helpdesk.controllers.portal import CustomerPortal
from odoo.addons.portal.controllers.portal import pager as portal_pager


class WebsiteTicketsPac(CustomerPortal):
    @http.route(['/my/tickets', '/my/tickets/page/<int:page>'], type='http', auth="user", website=True)
    def my_helpdesk_tickets(self, page=1, date_begin=None, date_end=None, sortby=None, filterby=None, search=None,
                            search_in='content',
                            **kw):
        values = self._prepare_portal_layout_values()
        user = request.env.user
        domain = []

        searchbar_sortings = {
            'date': {'label': _('Newest'), 'order': 'create_date desc'},
            'name': {'label': _('Subject'), 'order': 'name'},
            # 'user': {'label': _('User'), 'order': 'user_id'},
        }
        searchbar_inputs = {
            'content': {'input': 'content', 'label': _('Search <span class="nolabel"> (in Content)</span>')},
            'message': {'input': 'message', 'label': _('Search in Messages')},
            'customer': {'input': 'customer', 'label': _('Search in Customer')},
            'id': {'input': 'id', 'label': _('Search ID')},
            'all': {'input': 'all', 'label': _('Search in All')},
            # new===========
            'ticket_key': {'input': 'ticket_key', 'label': _('Search Key')},
            'name': {'input': 'name', 'label': _('Search Name')},
            'user_id': {'input': 'user_id', 'label': _('Search User')},
            'assign_date': {'input': 'assign_date', 'label': _('Search Assign Date')},
            'stage_id': {'input': 'stage_id', 'label': _('Search Stage')},
            # new===========
        }

        # default sort by value
        if not sortby:
            sortby = 'date'
        order = searchbar_sortings[sortby]['order']

        # archive groups - Default Group By 'create_date'
        archive_groups = self._get_archive_groups('helpdesk.ticket', domain)
        if date_begin and date_end:
            domain += [('create_date', '>', date_begin), ('create_date', '<=', date_end)]

        # search
        if search and search_in:
            search_domain = []
            if search_in in ('id', 'all'):
                search_domain = OR([search_domain, [('id', 'ilike', search)]])
            if search_in in ('content', 'all'):
                search_domain = OR([search_domain, ['|', ('name', 'ilike', search), ('description', 'ilike', search)]])
            if search_in in ('customer', 'all'):
                search_domain = OR([search_domain, [('partner_id', 'ilike', search)]])
            if search_in in ('message', 'all'):
                search_domain = OR([search_domain, [('message_ids.body', 'ilike', search)]])
            # add search==========
            if search_in in ('ticket_key', 'all'):
                search_domain = OR([search_domain, [('ticket_key', 'ilike', search)]])
            if search_in in ('name', 'all'):
                search_domain = OR([search_domain, [('name', 'ilike', search)]])
            if search_in in ('user_id', 'all'):
                search_domain = OR([search_domain, [('user_id', 'ilike', search)]])
            if search_in in ('assign_date', 'all'):
                search_domain = OR([search_domain, [('assign_date', 'ilike', search)]])
            if search_in in ('stage_id', 'all'):
                search_domain = OR([search_domain, [('stage_id', 'ilike', search)]])
            # add search==========
            domain += search_domain

        # add filter by ticket key=========================================
        searchbar_filters = {
            'all': {'label': _('All'), 'domain': []},
        }
        tickets = request.env['helpdesk.ticket'].search([])
        key = []
        for i in tickets:
            assign_date = str(i.assign_date)
            if assign_date != 'False' and assign_date[:7] not in key:
                key.append(assign_date[:7])
        for ticket in key:
            dates = ticket.split('-')
            date_begin = '%s-%s-01' % (str(dates[0]), str(dates[1]))
            date_end = '%s-%s-01' % (str(dates[0]), str(int(dates[1]) + 1).zfill(2))
            if int(dates[1]) == 12:
                date_end_year = int(dates[0]) + 1
                date_end_month = '01'
                date_end = '%s-%s-01' % (str(date_end_year), str(date_end_month))
            searchbar_filters.update({
                str(ticket): {'label': ticket,
                              'domain': [('assign_date', '>=', date_begin), ('assign_date', '<', date_end)]}
            })
        # default filter by value
        if not filterby:
            filterby = 'all'
        domain += searchbar_filters[filterby]['domain']
        # add filter by ticket key=========================================
        # pager
        tickets_count = request.env['helpdesk.ticket'].search_count(domain)
        pager = portal_pager(
            url="/my/tickets",
            url_args={'date_begin': date_begin, 'date_end': date_end, 'sortby': sortby, 'filterby': filterby},
            total=tickets_count,
            page=page,
            step=self._items_per_page
        )

        tickets = request.env['helpdesk.ticket'].search(domain, order=order, limit=self._items_per_page,
                                                        offset=pager['offset'])
        request.session['my_tickets_history'] = tickets.ids[:100]

        values.update({
            'date': date_begin,
            'tickets': tickets,
            'page_name': 'ticket',
            'default_url': '/my/tickets',
            'pager': pager,
            'archive_groups': archive_groups,
            'searchbar_sortings': searchbar_sortings,
            'searchbar_inputs': searchbar_inputs,
            'sortby': sortby,
            'search_in': search_in,
            'search': search,
            'searchbar_filters': OrderedDict(sorted(searchbar_filters.items())),
            'filterby': filterby,
        })
        return request.render("helpdesk.portal_helpdesk_ticket", values)
