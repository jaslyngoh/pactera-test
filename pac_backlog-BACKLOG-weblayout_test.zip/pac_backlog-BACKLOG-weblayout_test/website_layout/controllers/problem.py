# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


from odoo import http
from odoo.http import request


class OdooProblem(http.Controller):
    @http.route('/problem', type='http', auth="public", website=True)
    def odoo_problem(self, **kw):
        values = {}
        return request.render("website_layout.odoo_problem_page", values)
