# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


from odoo import http
from odoo.http import request


class WebsiteClubSummary(http.Controller):
    @http.route('/club_summary', type='http', auth="public", website=True)
    def website_club_summary_page(self, **kw):
        values = {}
        return request.render("website_layout.website_club_summary_page", values)
