# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import task
from . import ticket
from . import club_summary
from . import trouble
from . import problem
