# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


from odoo import http
from odoo.http import request


class OdooTrouble(http.Controller):
    @http.route('/trouble', type='http', auth="public", website=True)
    def odoo_trouble(self, **kw):
        values = {}
        return request.render("website_layout.odoo_trouble_page", values)
