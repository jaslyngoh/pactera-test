# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.


{
    'name': "Data Migration",
    'summary': """Backlog Data Migration""",
    'description': """Backlog Data Migration""",
    'author': "Pactera DL",
    'website': "https://japan-odoo.com/",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'helpdesk', 'project', 'pac_project', 'pac_helpdesk'],
    'data': [
        'data/data_migration_schedule.xml',
    ],
    'application': False,
    'installable': True,
}
