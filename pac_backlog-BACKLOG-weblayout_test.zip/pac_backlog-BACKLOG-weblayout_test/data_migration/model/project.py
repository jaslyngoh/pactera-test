# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import json
import base64
import datetime

from urllib.parse import unquote

from odoo import api, fields, models

from pybacklogpy.BacklogConfigure import BacklogComConfigure
from pybacklogpy.Issue import Issue, IssueComment, IssueAttachment
from pybacklogpy.Category import Category
from pybacklogpy.User import User
from pybacklogpy.Project import Project as Project_obj

manager = {
    'wander.zhang@pactera.com': 'Wander',
    'takamitsu.nakao@pactera.com': '中尾貴光',
    'toru.nameda@pactera.com': '滑田徹',
    'masako.ogawa@pactera.com': '小川雅子',
    'yoshihiro.maezono@pactera.com': '前園義博',
    'jaslyn.goh@pactera.com': 'Jaslyn',
    'nankyung.yoon@pactera.com': 'Yoon',
}
user = {
    'thang.le@pactera.com': 'ThangLe',
    'huan.li22@pactera.com': '李環',
    'naoki.shinoda@pactera.com': '篠田尚樹',
    'javen.zhang@pactera.com': 'Javen',
    'haochen.dong@pactera.com': '董昊辰',
    'bowen.jiang2@pactera.com': '姜博文',
    'yinghua.wang@pactera.com': '王英华',
    'wen.wen1@pactera.com': 'Wen Wen',
    'xinliang.liu@pactera.com': '劉新亮',
    'yunfei.zhang3@pactera.com': '張雲飛',
}
customer = {
    'sbt1@com': 'sakubo',
    'sbt2@com': 'よう',
    'mi71@com': '柳澤圭',
    'mi72@com': '桜井 正俊',
    'sbt3@com': '業未管理G',
    'mi73@com': '渡邉篤史',
    'mi74@com': '鈴木',
}
# 评论超过20条的issue
result = {'SBT': ['SBT-23', 'SBT-27', 'SBT-41', 'SBT-53', 'SBT-61', 'SBT-63', 'SBT-64', 'SBT-67', 'SBT-71', 'SBT-77'],
          'SHARE_MI7': ['SHARE_MI7-12', 'SHARE_MI7-18', 'SHARE_MI7-23', 'SHARE_MI7-71', 'SHARE_MI7-74', 'SHARE_MI7-83',
                        'SHARE_MI7-85', 'SHARE_MI7-98', 'SHARE_MI7-122', 'SHARE_MI7-124', 'SHARE_MI7-149',
                        'SHARE_MI7-151', 'SHARE_MI7-197', 'SHARE_MI7-205', 'SHARE_MI7-208', 'SHARE_MI7-221',
                        'SHARE_MI7-226', 'SHARE_MI7-250', 'SHARE_MI7-252', 'SHARE_MI7-262', 'SHARE_MI7-290',
                        'SHARE_MI7-295', 'SHARE_MI7-312'],
          }
# 评论在40条以内的issue key及对应的评论id
message_ids = {
    "SBT-23": [9933149, 10011189, 10017626, 10019462, 10232793, 10232812, 10241923, 10358727, 10358771, 10358820,
               10485249, 10627719, 10698592, 10707727, 10713160, 10746691, 10772208, 10778711, 10782133, 10833314,
               11069105, 10935577, 10931960, 10929597, 10837474],
    "SBT-27": [10234882, 10338519, 10343731, 10343738, 10358793, 10362825, 10408616, 10485224, 10486470, 10535386,
               10539742, 10559515, 10597160, 10622561, 10622952, 10735556, 10772048, 10927819, 10931939, 10945151,
               12130529, 11997957, 11997550, 11997315, 11993660, 11984821, 11984262, 11983868, 11982354, 11981766,
               11804520, 11661412, 11656573, 11623994, 11623728, 11618239, 11615011, 11610571, 11560259, 11135068],
    "SBT-41": [11297644, 11561985, 11578106, 11600488, 11607885, 11610820, 11847238, 11848897, 11894154, 11910634,
               11919904, 11921775, 11958878, 11981749, 11986913, 11987412, 12007745, 12008326, 12008609, 12117619,
               12340311, 12141322, 12138491, 12129096, 12127916, 12124320, 12124002, 12120131],
    "SBT-53": [11374878, 11374898, 11376336, 11409636, 11475382, 11496837, 11504434, 11517804, 11526785, 11526870,
               11540944, 11562291, 11578572, 11585356, 11593501, 11603421, 11609531, 11620807, 11655371, 11662137,
               11662297],
    "SBT-61": [12202526, 12203193, 12454676, 12467332, 12728945, 12730085, 12791673, 12792007, 12793382, 12943189,
               12958613, 12994703, 12995590, 13007864, 13014110, 13020457, 13053496, 13101563, 13102974, 13171085],
    "SBT-63": [12203955, 12206420, 12207355, 12209457, 12209542, 12455246, 12467247, 12616973, 12617909, 12619541,
               12620341, 12630085, 12647343, 12653653, 12664554, 12725411, 12783735, 12793089, 12823407, 12901185,
               14097890, 13909426, 13909350, 13908522, 13888389, 13880075, 13870170, 13653386, 13650691, 13319299,
               13112576, 13051923, 13009630, 12954255],
    "SBT-64": [12206170, 12206203, 12214038, 12214468, 12757835, 14203066, 14204049, 14204684, 14205350, 14207946,
               14208862, 14209425, 14209867, 14211059, 14211430, 14213159, 14213181, 14215628, 14216437, 14393513,
               15457311, 15363014, 14419897, 14414813, 14394788],
    "SBT-67": [12340094, 12341850, 12365175, 12365984, 12366701, 12368158, 12368300, 12369652, 12411223, 12436368,
               12453553, 12456064, 12468739, 12469928, 12537367, 12548668, 12551959, 12555525, 12560687, 12560699,
               12663974, 12631908, 12577392, 12576138, 12566202, 12562432],
    "SBT-71": [12613938, 12708437, 12725200, 12890741, 12901316, 12903031, 12914955, 12948777, 12979444, 13009313,
               13013702, 13014188, 13019385, 13023627, 13030910, 13054458, 13100028, 13103196, 13135861, 13136166,
               14098449, 14098407, 13862964, 13651144, 13649046, 13648607, 13648271, 13648017, 13647744, 13646371,
               13645814, 13228993, 13225804, 13225443, 13172154, 13136478],
    "SBT-77": [13909262, 14105207, 14148235, 14200379, 14200400, 14205447, 14207820, 14214831, 14216155, 14221818,
               14374414, 15327049, 15357516, 15362707, 15463378, 15523928, 16003799, 16274987, 16342443, 17967530],
    "SHARE_MI7-12": [6210487, 6218256, 6237660, 6241998, 6838085, 6838159, 6935382, 6954345, 7156286, 7251279, 7294495,
                     7410130, 7412576, 7413146, 7413824, 7414723, 7510454, 7510464, 8177686, 8180333, 9283446, 8201442,
                     8201160, 8199272, 8195406, 8194884, 8194701, 8190366, 8180664],
    "SHARE_MI7-18": [6211527, 6279680, 6372562, 6376021, 6441605, 6624603, 6624944, 6625071, 6641387, 7237033, 7436018,
                     7441624, 7495027, 7576632, 7582483, 7583283, 7587669, 7590316, 7595084, 7595295, 8268910, 8266753,
                     8202466, 8202177, 8057469, 7969309],
    "SHARE_MI7-23": [6293554, 6312946, 6327467, 6327478, 6328609, 6329408, 6334245, 6334528, 6335444, 6335785, 6336316,
                     6339555, 6358525, 6366984, 6370976, 6371155, 6372478, 6379024, 6391968, 6396795, 9304570, 7520987,
                     6587603, 6586893, 6486541, 6470866, 6456483, 6453530, 6450428, 6449845, 6438369, 6433147, 6432544],
    "SHARE_MI7-71": [6509317, 6567388, 6586632, 6607052, 6607357, 6613322, 6622851, 6669566, 6705690, 6708491, 6710373,
                     6712784, 6734215, 6735800, 6784653, 6785312, 6786708, 6801209, 6839908, 6866330, 11217607,
                     11001320, 8239307, 8194936, 8193420, 8192405, 8188969, 8168333, 8156887, 8142844, 8142617, 8136434,
                     8127575, 8122172, 8094588, 8021670, 7978070, 7972792, 7964855, 7796364],
    "SHARE_MI7-74": [6526857, 6567358, 6567739, 6569784, 6569931, 6575523, 6579406, 6579623, 6579766, 6580167, 6580764,
                     6603681, 6606217, 6606553, 6606729, 6607273, 6608054, 6609841, 6617327, 6724459, 6840453],
    "SHARE_MI7-83": [6574739, 6576656, 6576671, 6871425, 6892998, 6893220, 6893570, 6893711, 6893921, 6894294, 6894511,
                     6894649, 7415301, 8081129, 8086285, 8086588, 8089413, 8089841, 8091927, 8266072, 9162168, 8385464,
                     8384722, 8379482, 8379373, 8374782, 8279543],
    "SHARE_MI7-85": [7619906, 8001373, 8142645, 8478338, 8838254, 8862232, 8862267, 8862274, 8862286, 8862301, 8862371,
                     8862448, 8862465, 8862525, 8862800, 8862844, 8862901, 8862994, 8863013, 8864461, 9304809, 8938711,
                     8938403, 8927487, 8876773, 8876173, 8875526, 8874581, 8874382, 8873624, 8872966, 8872934, 8872211,
                     8872091, 8869720, 8869407, 8868026, 8867590, 8866762, 8866427],
    "SHARE_MI7-98": [6857111, 7010733, 7225652, 7319622, 7319711, 7319812, 7322457, 7323175, 7358257, 7360744, 7521153,
                     7536312, 7536640, 7707326, 7835542, 7968939, 8098135, 8132162, 8134904, 8143249],
    "SHARE_MI7-122": [7416000, 7427491, 7443570, 7445841, 7460528, 7466683, 7467407, 7469755, 7472273, 7472487, 7519876,
                      7522621, 7523716, 7531666, 7613178, 7613794, 8068265, 8068547, 8081613, 8085532, 9162109, 8436982,
                      8436794, 8436587, 8086147],
    "SHARE_MI7-124": [7417345, 7445855, 7474380, 7474697, 7520903, 7649535, 7653143, 7653696, 7654471, 7654767, 7654841,
                      7656510, 7657166, 7669067, 7671966, 7717770, 7718021, 7728194, 7728552, 7729305, 9305017, 8862230,
                      8846191, 8703110, 8700562, 8694827, 8648634, 8645556, 8635694, 8633861, 8632812, 8619359, 8613762,
                      8612623, 8612242, 8611923, 8611645, 8610997, 8609671, 8609301],
    "SHARE_MI7-149": [8355180, 8355183, 8424712, 8426757, 8591472, 8593028, 8595383, 8606457, 8611362, 8618703, 8661178,
                      8664005, 8667085, 8687300, 8687470, 8699895, 8701652, 8701855, 8702288, 8712633, 11217623,
                      11001562, 8810033, 8809599, 8775867, 8772405, 8771433, 8758199, 8743170, 8728516, 8720258,
                      8719634, 8714927, 8714109],
    "SHARE_MI7-151": [8438431, 8446787, 8476619, 8605934, 8608412, 8637776, 8638262, 8648089, 8649471, 8649708, 8649763,
                      8650636, 8656655, 8688584, 8688880, 8688903, 8703764, 8704296, 8704490, 8704566, 9305274, 8741730,
                      8738912, 8733197, 8730264, 8729474, 8729043, 8707183, 8706919, 8704678],
    "SHARE_MI7-197": [9065690, 9162106, 9162601, 9162641, 9162945, 9163091, 9163219, 9163410, 9163799, 9164111, 9164582,
                      9166206, 9170127, 9201349, 9202162, 9204181, 9204339, 9206643, 9213474, 9226232, 11004799,
                      9278265, 9275014, 9247223, 9245121, 9244514, 9243873, 9243385, 9242000, 9241459, 9239396, 9239030,
                      9237448, 9237036, 9235727, 9235587, 9235028, 9228119, 9227030],
    "SHARE_MI7-205": [9121706, 9121709, 9129331, 9139906, 9141061, 9141618, 9143455, 9148344, 9148614, 9149846, 9151121,
                      9162611, 9203344, 9213223, 9217570, 9307582, 9315106, 9317207, 9330840, 9333029, 11005365,
                      9405262, 9404971, 9404486, 9400865, 9395973, 9391650, 9337321],
    "SHARE_MI7-208": [9129647, 9130470, 9137134, 9151835, 9151979, 9152263, 9152802, 9156027, 9157191, 9157284, 9158557,
                      9159169, 9178829, 9196957, 9197394, 9329210, 9544228, 10588355, 11218153, 12710034, 12788570,
                      12775684],
    "SHARE_MI7-221": [9448578, 9452156, 9458633, 9460408, 9460924, 9460941, 9461222, 9461263, 9463594, 9464783, 9476850,
                      9483245, 9490450, 9495671, 9504545, 9517566, 9530766, 9541744, 9560042, 9613852, 11005930,
                      10183505, 10157565, 10152889, 10049249, 10039389, 9805760, 9676867],
    "SHARE_MI7-226": [9550206, 9700661, 9701482, 9724021, 9731651, 9734126, 9736667, 9740466, 9787011, 9797734, 9838975,
                      9981604, 9983349, 10040742, 10155123, 10165295, 10183932, 10184829, 10186779, 10229091, 12772055,
                      12758245, 12710094, 11218214, 11006111, 10787559, 10785787, 10784312, 10780340, 10760457,
                      10747623, 10704199, 10627443, 10626868, 10626768, 10617030, 10595125, 10588189, 10369920,
                      10243864],
    "SHARE_MI7-250": [10423115, 10514268, 11000676, 11075377, 11117639, 11125095, 11543580, 11544049, 11548093,
                      11549009, 11550017, 11550375, 11551145, 11556192, 11557123, 11558211, 11558872, 11579193,
                      11581165, 11587357],
    "SHARE_MI7-252": [10499190, 10502047, 10587564, 10620403, 10739097, 10763001, 10781347, 11008582, 11221300,
                      12242861, 12243964, 12551984, 12710872, 12782056, 13647743, 13648149, 13649734, 13651275,
                      13653561, 13654451, 18785476, 13847610, 13657626, 13656812],
    "SHARE_MI7-262": [10802159, 10804551, 10804631, 10810446, 10810451, 10830468, 10830761, 10831213, 10831657,
                      10832131, 10833500, 10833786, 10837910, 10866573, 10888770, 10896831, 10971882, 11003235,
                      11004334, 11824069, 11825507],
    "SHARE_MI7-290": [11801324, 11801542, 11802396, 11802554, 11802665, 11803329, 11805587, 11816936, 11832044,
                      11995303, 11995642, 12024282, 12082498, 12083289, 12711576, 12782143, 12822473, 13076473,
                      16336355, 16371842, 18768591, 18141301, 18139411, 18040910, 18036649, 18036403, 18033696,
                      18033256, 18033061, 18032469, 18031907, 18003003, 17946366, 16400666, 16389380, 16388401,
                      16382319],
    "SHARE_MI7-295": [12089483, 12093087, 12093134, 12093182, 12093325, 12093838, 12100479, 12126983, 12131764,
                      12782025, 13076312, 13108454, 13110002, 13115705, 13116018, 13117343, 13117676, 13118181,
                      13118286, 13119484, 13154492, 13153662, 13150972, 13144926],
    "SHARE_MI7-312": [13871177, 13871446, 13871595, 13875310, 13880410, 13883428, 13883803, 13888153, 13891842,
                      13894984, 13895326, 13900387, 13901555, 13903939, 14071381, 14071716, 14088037, 14092322,
                      14103228, 14173244, 14186143, 14184665, 14175307],

}


class ProjectData(models.Model):
    _inherit = "project.task"

    def create_category_group(self, name):
        Category = self.env['project.category.type']
        values = {
            'category_group': name,
        }
        result = Category.create(values)
        return result

    def create_category_item(self, name, category_id):
        Item = self.env['project.category.item']
        values = {
            'name': name,
            'category_id': category_id,
        }
        result = Item.create(values)
        return result

    def create_project(self, name, key_name, category_group_id):
        Team = self.env['project.project']
        values = {
            'name': name,
            'key_name': key_name,
            'category_group': category_group_id,
        }
        result = Team.create(values)
        return result

    # write stages
    def write_stage(self, stage, team_id):
        result = stage.write({
            'project_ids': [(4, team_id, 0)],
        })
        return result

    def create_user(self, name, email):
        UserObj = self.env['res.users']
        if email in manager:
            name = manager[email]
            groups_id = [(4, self.env.ref('helpdesk.group_helpdesk_manager').id),
                         (4, self.env.ref('project.group_project_manager').id)]
        elif email in user:
            name = user[email]
            groups_id = [(4, self.env.ref('helpdesk.group_helpdesk_user').id),
                         (4, self.env.ref('project.group_project_user').id)]
        else:
            name = name
            groups_id = [(4, self.env.ref('base.group_public').id)]
        result = UserObj.create({
            'name': name,
            'login': email,
            'email': email,
            'password': email,
            'groups_id': groups_id,
        })
        return result

    @api.model
    def _schedule_data_migration_project(self, projects=['INT_ODOO', 'SBT', 'MI7_2', 'SHARE_MI7', 'BACKLOG'],
                                         space_key='***', api_key='******'):
        config = BacklogComConfigure(space_key=space_key, api_key=api_key)
        UserObj = self.env['res.users']
        StageObj = self.env['project.task.type']
        CategoryTypeObj = self.env['project.category.type']
        CategoryItemObj = self.env['project.category.item']
        TeamObj = self.env['project.project']
        TicketObj = self.env['project.task']
        IssueTypeObj = self.env['project.task.type.master']
        MailMessage = self.env['mail.message']
        MailTrackingValue = self.env['mail.tracking.value']
        user_api = User(config)
        issue_api = Issue(config)
        category_api = Category(config)
        project_api = Project_obj(config)
        comment_api = IssueComment(config)
        attachment_api = IssueAttachment(config)

        # =====================User==========================
        user_result = json.loads(user_api.get_user_list().text)
        for user in user_result:
            user_sys = UserObj.search([('login', '=', user['mailAddress'])])
            if not user_sys:
                self.create_user(name=user['name'], email=user['mailAddress'])
        # =====================User==========================
        p = 0
        # 项目循环
        for project_id_or_key in projects:
            p += 1
            # =====================Category==========================
            category_group = CategoryTypeObj.search([('category_group', '=', project_id_or_key)])
            if not category_group:
                category_group = self.create_category_group(name=project_id_or_key)
                category_result = json.loads(category_api.get_category_list(project_id_or_key=project_id_or_key).text)
                for category in category_result:
                    self.create_category_item(name=str(category['name']), category_id=category_group.id)
            # =====================Category==========================
            # =====================Team==========================
            project_result = json.loads(project_api.get_project(project_id_or_key=project_id_or_key).text)
            team_result = TeamObj.search([('name', '=', project_id_or_key)])
            if not team_result:
                team_result = self.create_project(name=project_id_or_key,
                                                  key_name=project_result['projectKey'].replace('-', '_'),
                                                  category_group_id=category_group.id)
                # =====================Team==========================
            # =====================Issue==========================
            issue_response = issue_api.get_issue_list(project_id=project_result['id'])
            issue_results = json.loads(issue_response.text)
            # 取项目的最大key值 通过issue key取得所有issue，因为api接口只可以取到20条issue数据
            max_key = issue_results[0]['issueKey']
            issue_list = range(1, int(max_key.split('-')[-1]) + 1)
            print("max_key:", max_key)
            print("Project:", project_result['name'], "total issue:", len(issue_list))
            # 循环issue
            for issue_key in issue_list:
                issue_id_or_key = project_id_or_key + '-' + str(issue_key)
                issue = json.loads(issue_api.get_issue(issue_id_or_key=issue_id_or_key).text)
                print(issue)
                print("===============" + str(issue_key) + '/' + str(len(issue_list)), "====project", str(p) + "/",
                      len(projects))
                # ticket对应的status------------------------
                if issue.get('errors'):
                    pass
                else:
                    if issue['status']:
                        backlog_name = issue['status']['name']
                        status = StageObj.search([('name', '=', backlog_name)], limit=1)
                        if status:
                            status_id = status.id
                            self.write_stage(stage=status, team_id=team_result.id)
                        else:
                            status = StageObj.create({'name': backlog_name})
                            status_id = status.id
                            self.write_stage(stage=status, team_id=team_result.id)
                    else:
                        status_id = False
                    # ticket对应的status------------------------

                    # ticket对应的Assignee create uid------------------------
                    if issue['assignee']:
                        user_id = UserObj.search([('login', '=', issue['assignee']['mailAddress'])], limit=1).id
                        if not user_id:
                            user_id = self.create_user(name=issue['assignee']['name'],
                                                       email=issue['assignee']['mailAddress']).id
                    else:
                        user_id = None
                    if issue['createdUser']:
                        create_uid = UserObj.search([('login', '=', issue['createdUser']['mailAddress'])], limit=1).id
                    else:
                        create_uid = False
                    # ticket对应的Assignee create uid------------------------

                    # issueType------------------------
                    if issue['issueType']:
                        issue_type_id = IssueTypeObj.search([('name', '=', issue['issueType']['name'])], limit=1).id
                        if not issue_type_id:
                            issue_type_id = IssueTypeObj.create({'name': issue['issueType']['name']}).id
                    else:
                        issue_type_id = False
                    # issueType------------------------

                    # Category Item------------------------
                    if issue['category']:
                        category_item_id = CategoryItemObj.search([('name', '=', issue['category'][0]['name'])],
                                                                  limit=1).id
                        if not category_item_id:
                            category_item_id = self.create_category_item(name=category['name'],
                                                                         category_id=category_group.id).id
                    else:
                        category_item_id = False
                    # Category Item------------------------
                    scheduled_time = issue['estimatedHours'] if issue['estimatedHours'] else ''
                    actual_time = issue['actualHours'] if issue['actualHours'] else ''
                    backlog_priority = issue['priority']['name'] if issue['priority'] else ''
                    if backlog_priority == 'High':
                        priority = 1
                    else:
                        priority = 0
                    task_comment_create_date = 0
                    if issue['startDate']:
                        planned_date_start = datetime.datetime.strptime(issue['startDate'], "%Y-%m-%dT%H:%M:%SZ")
                    else:
                        planned_date_start = None
                    if issue['dueDate']:
                        planned_date_end = datetime.datetime.strptime(issue['dueDate'], "%Y-%m-%dT%H:%M:%SZ")
                    else:
                        planned_date_end = None
                    if issue['parentIssueId']:
                        issue_id = json.loads(issue_api.get_issue(issue_id_or_key=issue['parentIssueId']).text)
                        issue_name = issue_id['summary']
                        parent_result = TicketObj.search([('name', '=', issue_name)], limit=1)
                        if parent_result:
                            parent_id = parent_result.id
                        else:
                            print("search not found,**************************************")
                            parent_id = None
                    else:
                        parent_id = None
                    ticket_values = {
                        'task_key': issue['issueKey'].replace('_', '')[:8],
                        'name': issue['summary'],
                        'project_id': team_result.id,
                        'description': issue['description'],
                        'stage_id': status_id,
                        'scheduled_time': scheduled_time,
                        'actual_time': actual_time,
                        'category_id': category_item_id,
                        'task_type': issue_type_id,
                        'priority': str(priority),
                        'date_assign': issue['created'][:10],
                        'create_uid': create_uid,
                        'planned_date_begin': planned_date_start,
                        'planned_date_end': planned_date_end,
                        'date_deadline': planned_date_end,
                        'parent_id': parent_id,
                    }
                    ticket = TicketObj.create(ticket_values)
                    task_created_date = datetime.datetime.strptime(issue['created'],
                                                                   "%Y-%m-%dT%H:%M:%SZ")
                    task_updated_date = datetime.datetime.strptime(issue['updated'],
                                                                   "%Y-%m-%dT%H:%M:%SZ")
                    print("======create issue=====", ticket)
                    self._cr.execute(
                        "UPDATE project_task SET create_date = %s,write_date = %s,user_id = %s,task_key = %s WHERE id = %s",
                        [task_created_date, task_updated_date, user_id, issue['issueKey'].replace('-', '_'),
                         ticket.id])
                    # =====================Issue==========================
                    # comment ------------------------
                    comment_result = []
                    if result.get(project_id_or_key) and issue['issueKey'] in result[project_id_or_key]:
                        for comment_id in message_ids[issue['issueKey']]:
                            comment_record = json.loads(
                                comment_api.get_comment(issue_id_or_key=issue['issueKey'], comment_id=comment_id).text)
                            comment_result.append(comment_record)
                    else:
                        comment_result = json.loads(comment_api.get_comment_list(issue_id_or_key=issue['id']).text)
                    if comment_result:
                        for comment in comment_result:
                            comment_created_date = datetime.datetime.strptime(comment['created'],
                                                                              "%Y-%m-%dT%H:%M:%SZ")
                            comment_updated_date = datetime.datetime.strptime(comment['updated'],
                                                                              "%Y-%m-%dT%H:%M:%SZ")
                            if comment['createdUser']:
                                comment_partner_id = UserObj.search(
                                    [('login', '=', comment['createdUser']['mailAddress'])],
                                    limit=1).partner_id.id
                                comment_partner_email = issue['createdUser']['mailAddress']
                            else:
                                comment_partner_id = False
                                comment_partner_email = False

                            comment_values = {
                                'subject': issue['summary'],
                                'body': comment['content'] if comment['content'] else '',
                                'author_id': comment_partner_id,
                                'email_from': comment_partner_email,
                                'model': 'project.task',
                                'res_id': ticket.id,
                                'date': comment_updated_date,
                            }
                            # message的创建时间
                            if task_comment_create_date == 0:
                                task_comment_create_date += 1
                                mail_message_task = MailMessage.search(
                                    [('model', '=', 'project.task'), ('res_id', '=', ticket.id)])
                                if mail_message_task:
                                    mail_message_task.write({'date': ticket.create_date})
                            mail_message = MailMessage.create(comment_values)
                            self._cr.execute(
                                "UPDATE mail_message SET create_date = %s,write_date = %s,date = %s WHERE id = %s",
                                [comment_created_date, comment_updated_date, comment_updated_date, mail_message.id])
                            print("======create comment=====", mail_message)
                            if comment['changeLog']:
                                for record in comment['changeLog']:
                                    # 评论中更新状态
                                    if record['field'] == 'status':
                                        old_backlog_name = record['originalValue']
                                        new_backlog_name = record['newValue']
                                        old_status_id = StageObj.search([('name', '=', old_backlog_name)], limit=1).id
                                        if not old_status_id:
                                            old_status_id = StageObj.create({'name': old_backlog_name}).id
                                        new_status_id = StageObj.search([('name', '=', new_backlog_name)], limit=1).id
                                        if not new_status_id:
                                            new_status_id = StageObj.create({'name': new_backlog_name}).id
                                        tracking_value = {
                                            'field': 'stage_id',
                                            'field_type': 'many2one',
                                            'field_desc': 'Stage',
                                            'old_value_integer': old_status_id,
                                            'old_value_char': record['originalValue'],
                                            'new_value_integer': new_status_id,
                                            'new_value_char': record['newValue'],
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新描述
                                    if record['field'] == 'description':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'description',
                                            'field_type': 'html',
                                            'field_desc': 'Description',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新开始日期
                                    if record['field'] == 'startDate':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'planned_date_begin',
                                            'field_type': 'datetime',
                                            'field_desc': 'startDate',
                                            'old_value_datetime': old_value,
                                            'new_value_datetime': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新结束日期
                                    if record['field'] == 'limitDate':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'planned_date_end',
                                            'field_type': 'datetime',
                                            'field_desc': 'limitDate',
                                            'old_value_datetime': old_value,
                                            'new_value_datetime': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新预计时间
                                    if record['field'] == 'estimatedHours':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'scheduled_time',
                                            'field_type': 'char',
                                            'field_desc': 'estimatedHours',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新实际时间
                                    if record['field'] == 'actualHours':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'actual_time',
                                            'field_type': 'char',
                                            'field_desc': 'actualHours',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新责任人
                                    if record['field'] == 'assigner':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'user_id',
                                            'field_type': 'many2one',
                                            'field_desc': 'User',
                                            # 'old_value_integer': old_value,
                                            'old_value_char': old_value,
                                            # 'new_value_integer': new_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新附件
                                    if record['field'] == 'attachment':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'attachment_ids',
                                            'field_type': 'many2many',
                                            'field_desc': 'Attachments',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新类别
                                    if record['field'] == 'component':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'category_id',
                                            'field_type': 'many2one',
                                            'field_desc': 'Category Item',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新种别
                                    if record['field'] == 'issueType':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'task_type',
                                            'field_type': 'many2one',
                                            'field_desc': 'task type',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新summary
                                    if record['field'] == 'summary':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'name',
                                            'field_type': 'char',
                                            'field_desc': 'summary',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新summary
                                    if record['field'] == 'priority':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'priority',
                                            'field_type': 'char',
                                            'field_desc': 'priority',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                        # comment------------------------
                        # attachments------------------------
                        attachments = issue['attachments']
                        if attachments:
                            for attachment in attachments:
                                attachment_path_result = attachment_api.get_issue_attachment(
                                    issue_id_or_key=issue['id'],
                                    attachment_id=attachment['id'])
                                path = attachment_path_result[0]
                                filename = unquote(attachment_path_result[0].split('/')[-1], 'utf-8')
                                file = open(path, 'rb')
                                created_time = datetime.datetime.strptime(attachment['created'],
                                                                          "%Y-%m-%dT%H:%M:%SZ")
                                attachment = self.env['ir.attachment'].create(
                                    {
                                        'name': filename,
                                        'datas': base64.b64encode(file.read()),
                                        'res_model': 'project.task',
                                        'res_id': ticket.id,
                                    })
                                self._cr.execute(
                                    "UPDATE ir_attachment SET create_date = %s,write_date = %s WHERE id = %s",
                                    [created_time, created_time, attachment.id])
                                print("======create attachment=====", attachment)
                                mail_message.attachment_ids = [(4, attachment.id)]
                    # attachments------------------------
