# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import json
import base64
import datetime

from urllib.parse import unquote

from odoo import api, fields, models

from pybacklogpy.BacklogConfigure import BacklogComConfigure
from pybacklogpy.Issue import Issue, IssueComment, IssueAttachment
from pybacklogpy.Category import Category
from pybacklogpy.User import User
from pybacklogpy.Project import Project as Project_obj

manager = {
    'wander.zhang@pactera.com': 'Wander',
    'takamitsu.nakao@pactera.com': '中尾貴光',
    'toru.nameda@pactera.com': '滑田徹',
    'masako.ogawa@pactera.com': '小川雅子',
    'yoshihiro.maezono@pactera.com': '前園義博',
    'jaslyn.goh@pactera.com': 'Jaslyn',
    'nankyung.yoon@pactera.com': 'Yoon',
}
user = {
    'thang.le@pactera.com': 'ThangLe',
    'huan.li22@pactera.com': '李環',
    'naoki.shinoda@pactera.com': '篠田尚樹',
    'javen.zhang@pactera.com': 'Javen',
    'haochen.dong@pactera.com': '董昊辰',
    'bowen.jiang2@pactera.com': '姜博文',
    'yinghua.wang@pactera.com': '王英华',
    'wen.wen1@pactera.com': 'Wen Wen',
    'xinliang.liu@pactera.com': '劉新亮',
    'yunfei.zhang3@pactera.com': '張雲飛',
}
customer = {
    'sbt1@com': 'sakubo',
    'sbt2@com': 'よう',
    'mi71@com': '柳澤圭',
    'mi72@com': '桜井 正俊',
    'sbt3@com': '業未管理G',
    'mi73@com': '渡邉篤史',
    'mi74@com': '鈴木',
}


class HelpdeskData(models.Model):
    _inherit = "helpdesk.ticket"

    def create_category_group(self, name):
        Category = self.env['helpdesk.category.type']
        values = {
            'category_group': name,
        }
        result = Category.create(values)
        return result

    def create_category_item(self, name, category_id):
        Item = self.env['helpdesk.category.item']
        values = {
            'name': name,
            'category_id': category_id,
        }
        result = Item.create(values)
        return result

    def create_helpdesk_team(self, name, key_name, category_group_id):
        Team = self.env['helpdesk.team']
        values = {
            'name': name,
            'key_name': key_name,
            'category_group': category_group_id,
        }
        result = Team.create(values)
        return result

    # write stages
    def write_stage(self, stage, team_id):
        result = stage.write({
            'team_ids': [(4, team_id, 0)],
        })
        return result

    def create_user(self, name, email):
        UserObj = self.env['res.users']
        if email in manager:
            name = manager[email]
            groups_id = [(4, self.env.ref('helpdesk.group_helpdesk_manager').id),
                         (4, self.env.ref('project.group_project_manager').id)]
        elif email in user:
            name = user[email]
            groups_id = [(4, self.env.ref('helpdesk.group_helpdesk_user').id),
                         (4, self.env.ref('project.group_project_user').id)]
        else:
            name = name
            groups_id = [(4, self.env.ref('base.group_public').id)]
        result = UserObj.create({
            'name': name,
            'login': email,
            'email': email,
            'password': email,
            'groups_id': groups_id,
        })
        return result

    @api.model
    def _schedule_data_migration_helpdesk(self,
                                          projects=['CHATERAISE_2', 'FTRADING', 'TURCKJAPAN', 'MI7', 'UNIFILLER_JAPAN',
                                                    'AIPHONE', '0PHOTO'], space_key='***', api_key='******'):
        config = BacklogComConfigure(space_key=space_key, api_key=api_key)
        UserObj = self.env['res.users']
        StageObj = self.env['helpdesk.stage']
        CategoryTypeObj = self.env['helpdesk.category.type']
        CategoryItemObj = self.env['helpdesk.category.item']
        TeamObj = self.env['helpdesk.team']
        TicketObj = self.env['helpdesk.ticket']
        IssueTypeObj = self.env['helpdesk.ticket.type']
        MailMessage = self.env['mail.message']
        MailTrackingValue = self.env['mail.tracking.value']
        user_api = User(config)
        category_api = Category(config)
        project_api = Project_obj(config)
        issue_api = Issue(config)
        comment_api = IssueComment(config)
        attachment_api = IssueAttachment(config)

        # =====================User==========================
        user_result = json.loads(user_api.get_user_list().text)
        for user in user_result:
            user_sys = UserObj.search([('login', '=', user['mailAddress'])])
            if not user_sys:
                self.create_user(name=user['name'], email=user['mailAddress'])
        # =====================User==========================
        p = 0
        # 项目循环
        for project_id_or_key in projects:
            p += 1
            # =====================Category==========================
            category_group = CategoryTypeObj.search([('category_group', '=', project_id_or_key)])
            if not category_group:
                category_group = self.create_category_group(name=project_id_or_key)
                category_result = json.loads(category_api.get_category_list(project_id_or_key=project_id_or_key).text)
                for category in category_result:
                    self.create_category_item(name=str(category['name']), category_id=category_group.id)
            # =====================Category==========================
            # =====================Team==========================
            project_result = json.loads(project_api.get_project(project_id_or_key=project_id_or_key).text)
            team_result = TeamObj.search([('name', '=', project_id_or_key)])
            if not team_result:
                team_result = self.create_helpdesk_team(name=project_id_or_key,
                                                        key_name=project_result['projectKey'].replace('-', '_'),
                                                        category_group_id=category_group.id)
                # =====================Team==========================
            # =====================Issue==========================
            issue_response = issue_api.get_issue_list(project_id=project_result['id'], count=99)
            issue_results = json.loads(issue_response.text)
            # 取项目的最大key值 通过issue key取得所有issue，因为api接口只可以取到20条issue数据
            max_key = issue_results[0]['issueKey']
            issue_list = range(1, int(max_key.split('-')[-1]) + 1)
            print("max_key:", max_key)
            print("Project:", project_result['name'], "total issue:", len(issue_list))
            # 循环issue
            for issue_key in issue_list:
                issue_id_or_key = project_id_or_key + '-' + str(issue_key)
                issue = json.loads(issue_api.get_issue(issue_id_or_key=issue_id_or_key).text)
                print("===============" + str(issue_key) + '/' + str(len(issue_list)), "====project", str(p) + "/",
                      len(projects))
                # ticket对应的status------------------------
                if issue.get('errors'):
                    pass
                else:
                    if issue['status']:
                        backlog_name = issue['status']['name']
                        status = StageObj.search([('name', '=', backlog_name)], limit=1)
                        if status:
                            status_id = status.id
                            self.write_stage(stage=status, team_id=team_result.id)
                        else:
                            status = StageObj.create({'name': backlog_name})
                            status_id = status.id
                            self.write_stage(stage=status, team_id=team_result.id)
                    else:
                        status_id = False
                    # ticket对应的status------------------------

                    # ticket对应的Assignee create uid------------------------
                    if issue['assignee']:
                        user_id = UserObj.search([('login', '=', issue['assignee']['mailAddress'])], limit=1).id
                        if not user_id:
                            user_id = self.create_user(name=issue['assignee']['name'],
                                                       email=issue['assignee']['mailAddress']).id
                    else:
                        user_id = None
                    if issue['createdUser']:
                        create_uid = UserObj.search([('login', '=', issue['createdUser']['mailAddress'])], limit=1).id
                    else:
                        create_uid = False
                    # ticket对应的Assignee create uid------------------------

                    # issueType------------------------
                    if issue['issueType']:
                        issue_type_id = IssueTypeObj.search([('name', '=', issue['issueType']['name'])], limit=1).id
                        if not issue_type_id:
                            issue_type_id = IssueTypeObj.create({'name': issue['issueType']['name']}).id
                    else:
                        issue_type_id = False
                    # issueType------------------------

                    # Category Item------------------------
                    if issue['category']:
                        category_item_id = CategoryItemObj.search([('name', '=', issue['category'][0]['name'])],
                                                                  limit=1).id
                        if not category_item_id:
                            category_item_id = self.create_category_item(name=category['name'],
                                                                         category_id=category_group.id).id
                    else:
                        category_item_id = False
                    # Category Item------------------------

                    # customer ------------------------
                    if issue['createdUser']:
                        partner_id = UserObj.search([('login', '=', issue['createdUser']['mailAddress'])],
                                                    limit=1).partner_id.id
                        partner_email = issue['createdUser']['mailAddress']
                    else:
                        partner_id = False
                        partner_email = False
                    # customer------------------------

                    scheduled_time = issue['estimatedHours'] if issue['estimatedHours'] else ''
                    actual_time = issue['actualHours'] if issue['actualHours'] else ''
                    backlog_priority = issue['priority']['name'] if issue['priority'] else ''
                    if backlog_priority == 'Low':
                        priority = 1
                    elif backlog_priority == 'Normal':
                        priority = 2
                    elif backlog_priority == 'High':
                        priority = 3
                    else:
                        priority = 0
                    ticket_comment_create_date = 0
                    ticket_values = {
                        'ticket_key': issue['issueKey'].replace('_', '')[:8],
                        'name': issue['summary'],
                        'team_id': team_result.id,
                        'description': issue['description'],
                        'stage_id': status_id,
                        'scheduled_time': scheduled_time,
                        'actual_time': actual_time,
                        'category_id': category_item_id,
                        'partner_id': partner_id,
                        'partner_email': partner_email,
                        'ticket_type_id': issue_type_id,
                        'priority': str(priority),
                        'assign_date': issue['created'][:10],
                        'create_uid': create_uid,
                    }
                    ticket = TicketObj.create(ticket_values)
                    ticket_created_date = datetime.datetime.strptime(issue['created'],
                                                                     "%Y-%m-%dT%H:%M:%SZ")
                    ticket_updated_date = datetime.datetime.strptime(issue['updated'],
                                                                     "%Y-%m-%dT%H:%M:%SZ")
                    print("======create issue=====", ticket)
                    self._cr.execute(
                        "UPDATE helpdesk_ticket SET create_date = %s,write_date = %s,user_id = %s,ticket_key = %s WHERE id = %s",
                        [ticket_created_date, ticket_updated_date, user_id, issue['issueKey'].replace('-', '_'),
                         ticket.id])
                    # =====================Issue==========================
                    # comment ------------------------
                    comment_result = json.loads(comment_api.get_comment_list(issue_id_or_key=issue['id']).text)
                    if comment_result:
                        for comment in comment_result:
                            comment_created_date = datetime.datetime.strptime(comment['created'],
                                                                              "%Y-%m-%dT%H:%M:%SZ")
                            comment_updated_date = datetime.datetime.strptime(comment['updated'],
                                                                              "%Y-%m-%dT%H:%M:%SZ")
                            if comment['createdUser']:
                                comment_partner_id = UserObj.search(
                                    [('login', '=', comment['createdUser']['mailAddress'])],
                                    limit=1).partner_id.id
                                comment_partner_email = issue['createdUser']['mailAddress']
                            else:
                                comment_partner_id = False
                                comment_partner_email = False
                            comment_values = {
                                'subject': issue['summary'],
                                'body': comment['content'] if comment['content'] else '',
                                'author_id': comment_partner_id,
                                'email_from': comment_partner_email,
                                'model': 'helpdesk.ticket',
                                'res_id': ticket.id,
                            }
                            # message的创建时间
                            if ticket_comment_create_date == 0:
                                ticket_comment_create_date += 1
                                mail_message_task = MailMessage.search(
                                    [('model', '=', 'helpdesk.ticket'), ('res_id', '=', ticket.id)])
                                if mail_message_task:
                                    mail_message_task.write({'date': ticket.create_date})
                            mail_message = MailMessage.create(comment_values)
                            self._cr.execute(
                                "UPDATE mail_message SET create_date = %s,write_date = %s,date = %s WHERE id = %s",
                                [comment_created_date, comment_updated_date, comment_updated_date, mail_message.id])
                            print("======create comment=====", mail_message)
                            if comment['changeLog']:
                                for record in comment['changeLog']:
                                    # 评论中更新状态
                                    if record['field'] == 'status':
                                        old_backlog_name = record['originalValue']
                                        new_backlog_name = record['newValue']
                                        old_status_id = StageObj.search([('name', '=', old_backlog_name)], limit=1).id
                                        if not old_status_id:
                                            old_status_id = StageObj.create({'name': old_backlog_name}).id
                                        new_status_id = StageObj.search([('name', '=', new_backlog_name)], limit=1).id
                                        if not new_status_id:
                                            new_status_id = StageObj.create({'name': new_backlog_name}).id
                                        tracking_value = {
                                            'field': 'stage_id',
                                            'field_type': 'many2one',
                                            'field_desc': 'Stage',
                                            'old_value_integer': old_status_id,
                                            'old_value_char': record['originalValue'],
                                            'new_value_integer': new_status_id,
                                            'new_value_char': record['newValue'],
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新描述
                                    if record['field'] == 'description':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'description',
                                            'field_type': 'html',
                                            'field_desc': 'Description',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新开始日期
                                    if record['field'] == 'startDate':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'planned_date_begin',
                                            'field_type': 'datetime',
                                            'field_desc': 'startDate',
                                            'old_value_datetime': old_value,
                                            'new_value_datetime': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新结束日期
                                    if record['field'] == 'limitDate':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'planned_date_end',
                                            'field_type': 'datetime',
                                            'field_desc': 'limitDate',
                                            'old_value_datetime': old_value,
                                            'new_value_datetime': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新预计时间
                                    if record['field'] == 'estimatedHours':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'scheduled_time',
                                            'field_type': 'char',
                                            'field_desc': 'estimatedHours',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新实际时间
                                    if record['field'] == 'actualHours':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'actual_time',
                                            'field_type': 'char',
                                            'field_desc': 'actualHours',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新责任人
                                    if record['field'] == 'assigner':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'user_id',
                                            'field_type': 'many2one',
                                            'field_desc': 'User',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新附件
                                    if record['field'] == 'attachment':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'attachment_ids',
                                            'field_type': 'many2many',
                                            'field_desc': 'Attachments',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新类别
                                    if record['field'] == 'component':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'category_id',
                                            'field_type': 'many2one',
                                            'field_desc': 'Category Item',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新种别
                                    if record['field'] == 'issueType':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'ticket_type_id',
                                            'field_type': 'many2one',
                                            'field_desc': 'ticket type',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新summary
                                    if record['field'] == 'summary':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'name',
                                            'field_type': 'char',
                                            'field_desc': 'summary',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                                    # 评论中更新summary
                                    if record['field'] == 'priority':
                                        old_value = record['originalValue']
                                        new_value = record['newValue']
                                        tracking_value = {
                                            'field': 'priority',
                                            'field_type': 'char',
                                            'field_desc': 'priority',
                                            'old_value_char': old_value,
                                            'new_value_char': new_value,
                                            'mail_message_id': mail_message.id,
                                        }
                                        MailTrackingValue.create(tracking_value)
                        # comment------------------------
                        # attachments------------------------
                        attachments = issue['attachments']
                        if attachments:
                            for attachment in attachments:
                                attachment_path_result = attachment_api.get_issue_attachment(
                                    issue_id_or_key=issue['id'],
                                    attachment_id=attachment['id'])
                                path = attachment_path_result[0]
                                filename = unquote(attachment_path_result[0].split('/')[-1], 'utf-8')
                                file = open(path, 'rb')
                                created_time = datetime.datetime.strptime(attachment['created'],
                                                                          "%Y-%m-%dT%H:%M:%SZ")
                                attachment = self.env['ir.attachment'].create({
                                    'name': filename,
                                    'datas': base64.b64encode(file.read()),
                                    'res_model': 'helpdesk.ticket',
                                    'res_id': ticket.id,
                                })
                                self._cr.execute(
                                    "UPDATE ir_attachment SET create_date = %s,write_date = %s WHERE id = %s",
                                    [created_time, created_time, attachment.id])
                                print("======create attachment=====", attachment)
                                mail_message.attachment_ids = [(4, attachment.id)]
                        # attachments------------------------
