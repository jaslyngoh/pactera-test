# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.


{
    'name': "Pac Project",
    'summary': """Add Fields To Project""",
    'description': """
                Add Project Key And Task Key To Project
                Add Scheduled Time and Actual Time to task
                Add WiKi notes
                Add task type field, and drop-down menu
              """,
    'author': "pactera DL",
    'website': "https://japan-odoo.com/",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'project'],
    'data': [
        'security/ir.model.access.csv',
        'views/project_category_item_view.xml',
        'views/project_category_view.xml',
        'views/project_project.xml',
        'views/project_task.xml',
        'views/project_task_type_views.xml',
        'views/project_wiki.xml',
        'views/project_task_wiki.xml',
        'views/menu.xml',
    ],
    'application': False,
    'installable': True,
}
