# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api
from odoo.tools import html2plaintext

class ProjectTag(models.Model):
    _name = "project.wiki.note.tag"
    _description = "Note Tag"

    name = fields.Char('Tag Name', required=True)
    color = fields.Integer('Color Index')

    _sql_constraints = [
        ('name_uniq', 'unique (name)', "Tag name already exists !"),
    ]


class ProjectNotePac(models.Model):
    _name = 'project.wiki.note'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Note"

    name = fields.Char(compute='_compute_note_name', string='Note Summary', store=True)
    user_id = fields.Many2one('res.users', string='Owner', default=lambda self: self.env.uid)
    memo = fields.Html('Note Content')
    color = fields.Integer(string='Color Index')
    tag_ids = fields.Many2many('project.wiki.note.tag', 'project_note_tags_rel', 'project_note_id', 'project_tag_id', string='Tags')
    project_id = fields.Many2one('project.project', index=True)

    @api.depends('memo')
    def _compute_note_name(self):
        """ Read the first line of the memo to determine the note name """
        for note in self:
            text = html2plaintext(note.memo) if note.memo else ''
            note.name = text.strip().replace('*', '').split("\n")[0][:40]
