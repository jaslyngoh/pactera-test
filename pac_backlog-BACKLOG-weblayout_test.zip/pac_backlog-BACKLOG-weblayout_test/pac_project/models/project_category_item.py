# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api


class ProjectCategoryItem(models.Model):
    _name = 'project.category.item'
    _description = 'Project Category Item'
    _order = 'sequence'

    name = fields.Char(string='Category Item', required=True, translate=True)
    category_id = fields.Many2one('project.category.type', string="Category")
    sequence = fields.Integer(default=10)
