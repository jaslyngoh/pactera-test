# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api


class ProjectTaskPac(models.Model):
    _inherit = 'project.task'

    task_key = fields.Char(string="Task Key", readonly=True)
    scheduled_time = fields.Char(string='Scheduled Time')  # Defining field types
    actual_time = fields.Char(string='Actual Time')
    # Add category filtering.
    category_id = fields.Many2one('project.category.item', string="Category", ondelete='restrict')
    category_id_display = fields.Many2one('project.category.type', string="Category id",
                                          related='project_id.category_group', store=True)
    # Create a task_type drop-down menu
    task_type = fields.Many2one('project.task.type.master', string='Task Type', required=True, ondelete='restrict')

    @api.onchange('project_id')
    def _onchange_team(self):
        self.category_id = False

    @api.model
    def create(self, vals):
        if vals.get('project_id'):
            project = self.env['project.project'].browse(vals['project_id'])
            key_name = project.key_name
            get_key_name = self.env['ir.sequence'].next_by_code(key_name)
            if get_key_name:
                vals['task_key'] = get_key_name
            # add task_key when creating
            tickets = super(ProjectTaskPac, self).create(vals)
            return tickets

    def write(self, vals):
        project = self.env['project.project'].browse(vals.get('project_id'))
        if project:
            name = str(project)
            key_name = project.key_name
            sq = self.env['ir.sequence'].sudo().search([('name', '=', name)])
            if sq:
                sq.write({'prefix': key_name + "_"})
            else:
                sq.create({'name': name, 'code': key_name, 'prefix': key_name + "_"})
            # Update the task_key when writing
            get_key_name = self.env['ir.sequence'].next_by_code(key_name)
            vals['task_key'] = get_key_name
        result = super(ProjectTaskPac, self).write(vals)
        return result


class ProjectTaskType(models.Model):
    _name = 'project.task.type.master'
    _description = 'Project Task Type'
    _order = 'sequence'

    name = fields.Char('Task Name', required=True)
    sequence = fields.Integer()

    # select Whether it has been called
    _sql_constraints = [
        ('name_uniq', 'unique (name)', "Type name already exists !"),
    ]
