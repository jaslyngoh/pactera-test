# -*- coding: utf-8 -*-
# Part of Pactera. See LICENSE file for full copyright and licensing details.
import re

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

# PROJECT KEY REGEX
PROJECT_KEY_REGEX = r'[a-zA-Z0-9_]+$'


class ProjectProjectPac(models.Model):
    _inherit = 'project.project'

    key_name = fields.Char(string="Project Key", required=True)
    category_group = fields.Many2one('project.category.type', string="Category", ondelete='restrict', required=True)

    # Data Verification: Project Key Unique
    _sql_constraints = [
        ('key_name_uniq', 'unique(key_name)', 'The project key name already exists.'),
    ]

    # PROJECT KEY REGEX
    @api.constrains('key_name')
    def _check_key_name(self):
        # Pop up warnings when not meet the conditions
        if not re.match(PROJECT_KEY_REGEX, self.key_name):
            raise ValidationError(_('Please enter half-width alphanumeric characters and _.'))

    @api.model
    def create(self, vals):
        project = super(ProjectProjectPac, self.with_context(mail_create_nosubscribe=True)).create(vals)
        name = str(project)
        key_name = project.key_name
        # create sequence
        self.env['ir.sequence'].sudo().create({'name': name, 'code': key_name, 'prefix': key_name + "_"})
        return project

    def write(self, vals):
        result = super(ProjectProjectPac, self).write(vals)
        if vals.get('key_name'):
            name = str(self)
            key_name = self.key_name
            sq = self.env['ir.sequence'].sudo().search([('name', '=', name)])
            if sq:
                sq.write({'name': name,
                          'code': key_name,
                          'prefix': key_name + "_"})
            else:
                self.env['ir.sequence'].sudo().create({'name': name, 'code': key_name, 'prefix': key_name + "_"})
            # Update the task_key of the ticket when modifying the project name
            projects = self.env['project.task'].sudo().search([('project_id', '=', self.id)])
            for project in projects:
                if project.task_key:
                    task_key = key_name + "_" + project.task_key.split('_')[-1]
                    project.write({'task_key': task_key})
        return result

    def unlink(self):
        name = str(self)
        sq = self.env['ir.sequence'].sudo().search([('name', '=', name)])
        if sq:
            sq.unlink()
        return super(ProjectProjectPac, self).unlink()
